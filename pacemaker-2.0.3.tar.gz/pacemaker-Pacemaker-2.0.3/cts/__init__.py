"""Python modules for Pacemaker's Cluster Test Suite (CTS)

This package provides the following modules:

CIB
cib_xml
CM_common
CM_corosync
CTSaudits
CTS
CTSscenarios
CTStests
CTSvars
environment
logging
patterns
remote
watcher
"""
